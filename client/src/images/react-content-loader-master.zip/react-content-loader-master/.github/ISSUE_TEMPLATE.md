## What did you do? 
Please include the actual source code causing the issue.

## What did you expect to happen?
Please mention the expected behaviour.

## What happened actually?

### Which versions of react-content-loader, and which browser are affected by this issue?
Please also mention the version of react.
